transactions = [
    {"uid": "1", "tid": "1", "type": "custo",
        "date": "2023/01/3", "cash": "400", "desc": "Job de motoboy"},
    {"uid": "2", "tid": "2", "type": "receita",
        "date": "2023/01/1", "cash": "3000", "desc": "Ganhei"},
    {"uid": "3", "tid": "3", "type": "custo",
        "date": "2023/02/22", "cash": "200", "desc": "Assalto"},
    {"uid": "4", "tid": "4", "type": "custo",
        "date": "2023/01/4", "cash": "2", "desc": "Formatei"},
    {"uid": "5", "tid": "5", "type": "receita",
        "date": "2023/01/02", "cash": "4000", "desc": "Serviço de limpeza"},
    {"uid": "6", "tid": "6", "type": "receita",
        "date": "asdasd", "cash": "3000", "desc": "Armario"},
    {"uid": "7", "tid": "7", "type": "custo",
        "date": "2023/01/12", "cash": "10000", "desc": "Bolsa"},

]
