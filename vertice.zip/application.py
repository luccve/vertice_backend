from flask import Flask, make_response, jsonify, request, render_template
from bd import transactions

import requests
from flask_cors import CORS

application = Flask(__name__)
CORS(application)
application.config['JSON_SORT_KEYS'] = False


@application.route('/', methods=['GET'])
def host():
    return render_template('index.html')


@application.route('/cnpj', methods=['GET'])
def get_cnpj():
    cnpj = request.args.get('cnpj')
    print(cnpj)
    url = f"https://receitaws.com.br/v1/cnpj/{cnpj}"

    headers = {"Content-Type": "application/json"}

    response = requests.request("GET", url, headers=headers)

    return make_response(response.text)


@application.route('/insertUser', methods=['POST'])
def insert():
    item = request.json

    return make_response(jsonify(item))


@application.route('/transaction', methods=['POST'])
def transaction():
    item = request.json
    transactions.append(item)
    return make_response(jsonify(item))


@application.route('/getTransaction', methods=['GET'])
def get_transaction():
    return make_response(jsonify(message="Lista das transaçoes",
                                 data=transactions))


@application.route('/changeTransaction', methods=['GET'])
def change_transaction():
    return make_response(jsonify(transactions))


if __name__ == '__main__':
    application.run(debug=True)
